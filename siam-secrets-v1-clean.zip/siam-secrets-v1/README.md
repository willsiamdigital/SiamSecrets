# Siam Secrets v1

Fresh clean build. No files from the contaminated project are required.

## Included
- 20 fictional/demo profiles
- Premium top 3 auction positions, starting at €50
- Profiles 4–9 as larger featured listings
- Profiles 10–20 as compact listings
- Search and area filtering
- Save/favourite interaction
- Auction demo modal with bid UI
- Monetisation section explaining featured inventory
- Sakura-inspired falling-petal animation
- Dark luxury UI with restrained blush-pink accents
- Responsive mobile layout

## Important
This is a front-end/demo build. The auction UI does **not** accept real money or create real bids. Production monetisation should use authenticated users, a server-side auction ledger, bid validation, payment provider, terms, moderation and fraud controls.

All profile names/data are fictional demo content. Replace placeholder images only with images you own or have licensed and ensure all listed people are adults.

## Run
```powershell
npm install
npm run dev
```
Then open the localhost URL shown by Vite.
