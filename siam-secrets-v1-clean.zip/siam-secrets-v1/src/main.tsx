import React,{useEffect,useMemo,useState} from 'react';
import {createRoot} from 'react-dom/client';
import {Heart,Search,MapPin,ShieldCheck,Share2,Flag,Clock3,ChevronRight,Menu,X,Gavel,Sparkles} from 'lucide-react';
import './styles.css';

type Profile={id:number;name:string;area:string;age:number;tag:string;image:string;featured?:boolean;auction?:boolean;bid?:number;status?:string};
const imgs=[
'https://images.unsplash.com/photo-1531123897727-8f129e1688ce?auto=format&fit=crop&w=900&q=85',
'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=900&q=85',
'https://images.unsplash.com/photo-1524250502761-1ac6f2e30d43?auto=format&fit=crop&w=900&q=85',
'https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?auto=format&fit=crop&w=900&q=85',
'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=900&q=85',
'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&w=900&q=85',
'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?auto=format&fit=crop&w=900&q=85',
'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=900&q=85',
'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=900&q=85',
'https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?auto=format&fit=crop&w=900&q=85',
'https://images.unsplash.com/photo-1512316609839-ce289d3eba0a?auto=format&fit=crop&w=900&q=85',
'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=900&q=85',
'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=900&q=85',
'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=900&q=85',
'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=900&q=85',
'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=900&q=85',
'https://images.unsplash.com/photo-1502823403499-6ccfcf4fb453?auto=format&fit=crop&w=900&q=85',
'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=900&q=85',
'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&w=900&q=85',
'https://images.unsplash.com/photo-1547425260-76bcadfb4f2c?auto=format&fit=crop&w=900&q=85'];
const names=[['Saorii','Sukhumvit'],['Ploy','Thong Lo'],['Nicha','Phrom Phong'],['Fah','Asok'],['Mint','Ekkamai'],['May','Silom'],['Fern','Sathorn'],['Nam','Ari'],['Aom','Ratchada'],['Dao','Nana'],['Bee','On Nut'],['Sai','Phaya Thai'],['Bow','Lat Phrao'],['Ploydao','Victory Monument'],['Mook','Chidlom'],['June','Bang Na'],['Ploysai','Huai Khwang'],['Ice','Khlong Toei'],['Lookkaew','Pratunam'],['Pim','Siam']];
const profiles:Profile[]=names.map(([name,area],i)=>({id:i+1,name,area,age:24+(i%7),tag:i<3?'Auction Feature':i<9?'Featured':'Directory',image:imgs[i],featured:i<9,auction:i<3,bid:i===0?50:i===1?75:100,status:'Available'}));

function Sakura(){const [petals,setPetals]=useState<number[]>([]);useEffect(()=>{setPetals(Array.from({length:22},(_,i)=>i));},[]);return <div className="sakura" aria-hidden>{petals.map(i=><span key={i} style={{left:`${(i*17)%100}%`,animationDelay:`${(i%9)*1.4}s`,animationDuration:`${9+(i%6)}s`,transform:`rotate(${i*31}deg)`}}>✿</span>)}</div>}
function App(){
 const [search,setSearch]=useState(''); const [area,setArea]=useState('All areas'); const [menu,setMenu]=useState(false); const [saved,setSaved]=useState<number[]>([]); const [auction,setAuction]=useState<number|null>(null); const [bid,setBid]=useState('');
 const filtered=useMemo(()=>profiles.filter(p=>(p.name+' '+p.area).toLowerCase().includes(search.toLowerCase())&&(area==='All areas'||p.area===area)),[search,area]);
 const toggleSave=(id:number)=>setSaved(s=>s.includes(id)?s.filter(x=>x!==id):[...s,id]);
 return <div className="app"><Sakura/><header><div className="brand"><div className="logo-mark">✦</div><div><div className="brand-name">Siam Secrets</div><div className="brand-sub">Bangkok's private directory</div></div></div><nav className={menu?'open':''}><a href="#directory">Directory</a><a href="#featured">Featured</a><a href="#how">How it works</a><button className="sell" onClick={()=>setAuction(0)}>List a profile</button></nav><button className="menu" onClick={()=>setMenu(!menu)}>{menu?<X/>:<Menu/>}</button></header>
 <main>
 <section className="hero"><div className="hero-copy"><span className="eyebrow"><Sparkles size={14}/> CURATED • DISCREET • BANGKOK</span><h1>Discover the <em>secrets</em><br/>of Siam.</h1><p>A premium directory experience with elegant listings, featured placement and a transparent marketplace for visibility.</p><div className="searchbar"><Search size={19}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search names or areas..."/><select value={area} onChange={e=>setArea(e.target.value)}><option>All areas</option>{[...new Set(profiles.map(p=>p.area))].map(a=><option key={a}>{a}</option>)}</select></div></div><div className="hero-tree"><div className="moon"></div><div className="tree">🌸</div><div className="tree-caption">A little privacy<br/><span>goes a long way.</span></div></div></section>
 <section className="trust"><span><ShieldCheck/> Demo profiles are clearly marked</span><span><MapPin/> Bangkok directory</span><span><Gavel/> Featured placement auctions</span></section>
 <section id="featured" className="section"><div className="section-head"><div><span className="eyebrow">THE SPOTLIGHT</span><h2>Featured <em>Secrets</em></h2></div><span className="auction-note">Top 3 placements start at <b>€50</b></span></div><div className="grid">{filtered.slice(0,3).map(p=><Card key={p.id} p={p} save={toggleSave} saved={saved.includes(p.id)} onAuction={()=>setAuction(p.id)}/>)}</div></section>
 <section id="directory" className="section"><div className="section-head"><div><span className="eyebrow">THE DIRECTORY</span><h2>More <em>profiles</em></h2></div><span className="count">{filtered.length} profiles</span></div><div className="grid normal">{filtered.slice(3,9).map(p=><Card key={p.id} p={p} save={toggleSave} saved={saved.includes(p.id)} onAuction={()=>setAuction(p.id)}/>)}</div><div className="grid compact">{filtered.slice(9).map(p=><Card key={p.id} p={p} save={toggleSave} saved={saved.includes(p.id)} onAuction={()=>setAuction(p.id)}/>)}</div></section>
 <section id="how" className="business"><div><span className="eyebrow">MONETISATION ENGINE</span><h2>Make visibility <em>valuable.</em></h2><p>The first three positions are premium inventory. Run a live auction, sell fixed sponsored slots, or offer recurring upgrades. The UI is ready for a real backend and payment provider.</p></div><div className="money-grid"><div><b>€50</b><span>Starting bid</span></div><div><b>3</b><span>Auction slots</span></div><div><b>4–9</b><span>Featured slots</span></div><div><b>10+</b><span>Compact listings</span></div></div></section>
 <section className="footer-cta"><h2>Want the top of the page?</h2><p>Featured placement can be sold by auction or subscription. No fake verification, no fake bidding, no pretend payments.</p><button onClick={()=>setAuction(1)}>View auction demo <ChevronRight size={17}/></button></section>
 </main><footer><b>Siam Secrets</b><span>Demo build • Replace placeholder imagery with owned/licensed assets before launch.</span><span>© 2026</span></footer>
 {auction!==null&&<div className="modal-back" onClick={()=>setAuction(null)}><div className="modal" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setAuction(null)}><X/></button><div className="modal-icon"><Gavel/></div><span className="eyebrow">AUCTION DEMO</span><h2>Featured placement</h2><p>This is a front-end demo. A real auction needs a backend, authenticated bidders, payment handling and server-side bid validation.</p><div className="auction-box"><span>Current demo bid</span><strong>€{profiles.find(p=>p.id===auction)?.bid||50}</strong><small>Starting bid €50 • Suggested increment €5</small></div><div className="bidrow"><input value={bid} onChange={e=>setBid(e.target.value)} placeholder="Enter bid €"/><button onClick={()=>{setBid('');alert('Demo only: bid not submitted.')}}>Place demo bid</button></div></div></div>}
 </div>
}
function Card({p,save,saved,onAuction}:{p:Profile;save:(id:number)=>void;saved:boolean;onAuction:()=>void}){return <article className={`card ${p.auction?'auction-card':''} ${p.id>9?'compact-card':''}`}><div className="photo"><img src={p.image} alt="Demo profile placeholder"/><div className="shade"></div><span className="badge">{p.auction?'AUCTION FEATURE':p.featured?'FEATURED':'DIRECTORY'}</span><button className={`heart ${saved?'active':''}`} onClick={()=>save(p.id)} aria-label="Save profile"><Heart fill={saved?'currentColor':'none'}/></button>{p.auction&&<button className="bid" onClick={onAuction}><Gavel size={14}/> Bid from €{p.bid}</button>}</div><div className="card-body"><div><h3>{p.name}, {p.age}</h3><p><MapPin size={14}/>{p.area}</p></div><span className="status"><i></i>{p.status}</span></div></article>}
createRoot(document.getElementById('root')!).render(<App/>);
